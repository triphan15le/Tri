const _WIDTH = 200;
const _HEIGHT = 400;
const _COLS = 10;
const _ROWS = 20;
const _SIZE = 20;

const _NEXTWIDTH = 90;
const _NEXTHEIGHT =75;
const _NEXTCOLS = 6;
const _NEXTROWS = 5;
const _NEXTSIZE = 15;// 

const _ = null;
const x = "x";
const _colorBr = 'grey';
const _colorBl = 'black';

const _BaseBrick = [
					[
						[x,x,x,x]
					],
					[
						[x,x],
						[x,x]
					],
					[
						[x,x,x],
						[_,_,x]
					],
					[
						[_,_,x],
						[x,x,x]
					],
					[
						[x,_],
						[x,x],
						[_,x]
					],
					[
						[_,x],
						[x,x],
						[x,_]
					],
					[
						[x,x,x],
						[_,x,_]
					]
				];


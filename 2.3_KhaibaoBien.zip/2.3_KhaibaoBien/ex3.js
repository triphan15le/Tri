var a = parseInt(prompt("Nhập số a:"));
var b = parseInt(prompt("Nhập số b:"));

if (a % b == 0) {
    alert("a là bội số của b");
} else {
    alert("a không phải là bội số của b");
}
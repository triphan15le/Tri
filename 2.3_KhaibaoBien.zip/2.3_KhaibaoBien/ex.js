var i = 10;
var f = 20.5;
var b = true;
var s = "Hà Nội";

document.write("i = " + i);
document.write("<br/>");
document.write("f = " + f);
document.write("<br/>");
document.write("b = " + b);
document.write("<br/>");
document.write("s = " + s);
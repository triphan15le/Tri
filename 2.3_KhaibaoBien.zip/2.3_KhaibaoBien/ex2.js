var width = 10;
var height = 20;
var area = width * height;

document.write("Diện tích hình chữ nhật = " + area);
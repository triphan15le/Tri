function checkEven() {
    var number = document.getElementById("numberInput").value;
    if (number % 2 == 0) {
        document.getElementById("result").innerHTML = number + " là số chẵn.";
    } else {
        document.getElementById("result").innerHTML = number + " không phải là số chẵn.";
    }
}


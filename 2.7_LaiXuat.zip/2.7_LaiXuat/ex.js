function tinhLaiDon(soTienVay, laiSuat, soNam) {
    let tongTienPhaiTra = soTienVay + (soTienVay * (laiSuat/100) * soNam);
    return tongTienPhaiTra;
}

let ketQua = tinhLaiDon(50, 6.9, 2);
console.log(ketQua);
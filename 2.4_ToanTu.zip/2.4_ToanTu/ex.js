// let inputWidth;
// let inputHeight;

// inputWidth = prompt("Enter the width");
// inputHeight = prompt("Enter the height");

// let width = parseInt(inputWidth);
// let height = parseInt(inputHeight);

// let area = width * height;
// document.write("The area is: " + area);

var width = parseInt(prompt("Nhập chiều rộng:"));
var height = parseInt(prompt("Nhập chiều cao:"));
var area = width * height;

alert("Diện tích hình chữ nhật = " + area);


var year = prompt("Nhập năm:");
var month = prompt("Nhập tháng:");
var day = prompt("Nhập ngày:");

var date = day + "-" + month + "-" + year;

document.write(date);
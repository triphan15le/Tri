let yourName = prompt("Hãy nhập tên của bạn");
// document.write("Xin chào " + yourName);
alert("Xin chào " + yourName);
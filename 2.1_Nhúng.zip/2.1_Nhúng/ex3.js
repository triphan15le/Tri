function showMessage(){
    alert('Xin chào!');
}
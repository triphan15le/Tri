var r = prompt("Ban kinh la: ");
const pi=3.14;

dientich = pi*r*r;
chuvi = 2*r*pi;

alert("dien tich hinh tron la: "+dientich+"\nchu vi hinh tron la: "+chuvi);


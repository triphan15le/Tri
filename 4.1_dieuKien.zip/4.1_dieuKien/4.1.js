let answer = prompt("What is the 'official' name of JavaScript?");
if (answer == "ECMAScript") {
    alert("Right!");
} else {
    alert("Didn’t know? ECMAScript!");
}